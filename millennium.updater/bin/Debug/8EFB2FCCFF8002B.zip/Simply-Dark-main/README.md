

<div align="center">

# Simply, Dark.

A break from Steam's new eyestraining theme

![Steam Skin](https://cdn.discordapp.com/attachments/923018893256167454/1139241592742482052/Screenshot_2023-08-10_135725.png)

</div>

## Installing

This theme is no longer being maintained. If any bugs present themselves that inherently affect your Steam experience, you can fix them, create a pull request and become a contributor/developer

## Building from source

The theme itself does not require anything being built, but to edit the theme you have to launch Steam with -dev mode.
This allows you to open the inspector on the Steam window, which allows you to edit CSS classes that you will forward to the theme

## Contributing

I encourage you to contribute. Anyone can create a pull request if it's deemed useful.
